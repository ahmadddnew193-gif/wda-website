import{j as e}from"./jsx-runtime.D_zvdyIk.js";import{r as i}from"./index.RH_Wq4ov.js";function m(){const d=i.useRef(null),[t,c]=i.useState({x:50,y:50}),[r,l]=i.useState(!1);return i.useEffect(()=>{const a=()=>{l(window.innerWidth<1024)};if(a(),window.addEventListener("resize",a),r)return()=>window.removeEventListener("resize",a);let n;const s=o=>{n&&cancelAnimationFrame(n),n=requestAnimationFrame(()=>{const p=o.clientX/window.innerWidth*100,u=o.clientY/window.innerHeight*100;c({x:p,y:u})})};return window.addEventListener("mousemove",s,{passive:!0}),()=>{window.removeEventListener("mousemove",s),window.removeEventListener("resize",a),n&&cancelAnimationFrame(n)}},[r]),e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"fixed inset-0 bg-black z-0"}),e.jsx("div",{ref:d,className:"fixed inset-0 pointer-events-none z-[1]",style:{background:r?`
              radial-gradient(circle at 20% 30%, rgba(59, 130, 246, 0.25) 0%, transparent 35%),
              radial-gradient(circle at 80% 70%, rgba(147, 51, 234, 0.2) 0%, transparent 35%),
              radial-gradient(circle at 50% 50%, rgba(14, 165, 233, 0.15) 0%, transparent 40%)
            `:`
              radial-gradient(circle 600px at ${t.x}% ${t.y}%, rgba(59, 130, 246, 0.25), rgba(147, 51, 234, 0.15) 40%, transparent 70%),
              radial-gradient(circle 400px at ${100-t.x}% ${100-t.y}%, rgba(168, 85, 247, 0.2), transparent 60%)
            `,transition:r?"none":"background 0.3s ease-out"}}),e.jsx("div",{className:"fixed inset-0 pointer-events-none z-[1] opacity-10",style:{backgroundImage:`
            linear-gradient(rgba(59, 130, 246, 0.3) 1px, transparent 1px),
            linear-gradient(90deg, rgba(59, 130, 246, 0.3) 1px, transparent 1px)
          `,backgroundSize:"80px 80px"}}),e.jsx("div",{className:"fixed top-0 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-[120px] pointer-events-none z-[1]"}),e.jsx("div",{className:"fixed bottom-0 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-[120px] pointer-events-none z-[1]"})]})}export{m as default};
