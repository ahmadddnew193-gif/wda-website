import {
  require_react_dom
} from "./chunk-VUVT7R4Q.js";
import "./chunk-LL2NLWCF.js";
import "./chunk-5WRI5ZAA.js";
export default require_react_dom();
