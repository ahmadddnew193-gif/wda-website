import {
  require_react
} from "./chunk-PSQR3SVX.js";
import "./chunk-5WRI5ZAA.js";
export default require_react();
