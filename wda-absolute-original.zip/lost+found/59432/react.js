import {
  require_react
} from "./chunk-NZP3G7XT.js";
import "./chunk-DC5AMYBS.js";
export default require_react();
