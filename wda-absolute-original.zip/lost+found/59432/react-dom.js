import {
  require_react_dom
} from "./chunk-MANNBT4V.js";
import "./chunk-NZP3G7XT.js";
import "./chunk-DC5AMYBS.js";
export default require_react_dom();
