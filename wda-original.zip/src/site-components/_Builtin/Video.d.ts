export declare const Video: any;
